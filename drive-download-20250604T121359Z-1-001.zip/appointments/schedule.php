<?php
header('Content-Type: application/json');
require_once '../config/database.php';
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'donor') {
    echo json_encode([
        'status' => 'error',
        'message' => 'Unauthorized access'
    ]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Validate input
        $required_fields = ['hospital_id', 'appointment_date', 'appointment_time'];
        foreach ($required_fields as $field) {
            if (!isset($_POST[$field]) || empty($_POST[$field])) {
                throw new Exception("$field is required");
            }
        }

        // Get donor_id
        $stmt = $pdo->prepare("SELECT donor_id FROM donors WHERE user_id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $donor = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$donor) {
            throw new Exception("Donor profile not found");
        }

        // Validate appointment date (must be future date)
        $appointment_date = new DateTime($_POST['appointment_date']);
        $today = new DateTime();
        if ($appointment_date < $today) {
            throw new Exception("Appointment date must be in the future");
        }

        // Check if donor has any existing appointments on the same date
        $stmt = $pdo->prepare("
            SELECT COUNT(*) FROM appointments 
            WHERE donor_id = ? AND appointment_date = ? AND status = 'scheduled'
        ");
        $stmt->execute([$donor['donor_id'], $_POST['appointment_date']]);
        if ($stmt->fetchColumn() > 0) {
            throw new Exception("You already have an appointment scheduled for this date");
        }

        // Check if hospital exists and is active
        $stmt = $pdo->prepare("SELECT hospital_id FROM hospitals WHERE hospital_id = ? AND status = 'active'");
        $stmt->execute([$_POST['hospital_id']]);
        if (!$stmt->fetch()) {
            throw new Exception("Invalid or inactive hospital");
        }

        // Insert appointment
        $stmt = $pdo->prepare("
            INSERT INTO appointments (donor_id, hospital_id, appointment_date, appointment_time, status) 
            VALUES (?, ?, ?, ?, 'scheduled')
        ");
        $stmt->execute([
            $donor['donor_id'],
            $_POST['hospital_id'],
            $_POST['appointment_date'],
            $_POST['appointment_time']
        ]);

        echo json_encode([
            'status' => 'success',
            'message' => 'Appointment scheduled successfully',
            'appointment_id' => $pdo->lastInsertId()
        ]);
    } catch (Exception $e) {
        echo json_encode([
            'status' => 'error',
            'message' => $e->getMessage()
        ]);
    }
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'Invalid request method'
    ]);
}
?> 