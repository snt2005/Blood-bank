<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

// Get JSON data
$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['unit_id']) || !isset($data['status'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Unit ID and status are required']);
    exit;
}

try {
    $pdo = getConnection();
    $pdo->beginTransaction();

    // Get blood unit information
    $stmt = $pdo->prepare("SELECT * FROM blood_units WHERE unit_id = ?");
    $stmt->execute([$data['unit_id']]);
    $unit = $stmt->fetch();

    if (!$unit) {
        throw new Exception('Blood unit not found');
    }

    // Update blood unit status
    $stmt = $pdo->prepare("UPDATE blood_units SET status = ? WHERE unit_id = ?");
    $stmt->execute([$data['status'], $data['unit_id']]);

    // Create notification for the hospital
    $stmt = $pdo->prepare("
        INSERT INTO notifications (user_id, message, type, created_at)
        SELECT h.user_id, ?, 'blood_unit_status', NOW()
        FROM hospitals h
        WHERE h.hospital_id = ?
    ");
    $stmt->execute([
        "Blood unit #{$data['unit_id']} has been marked as {$data['status']}",
        $unit['hospital_id']
    ]);

    $pdo->commit();
    echo json_encode(['success' => true]);

} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
} 