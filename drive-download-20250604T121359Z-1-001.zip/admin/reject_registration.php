<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

// Get JSON data
$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['user_id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'User ID is required']);
    exit;
}

try {
    $pdo = getConnection();
    $pdo->beginTransaction();

    // Get user information
    $stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ? AND status = 'pending'");
    $stmt->execute([$data['user_id']]);
    $user = $stmt->fetch();

    if (!$user) {
        throw new Exception('User not found or already processed');
    }

    // Update user status
    $stmt = $pdo->prepare("UPDATE users SET status = 'rejected' WHERE user_id = ?");
    $stmt->execute([$data['user_id']]);

    // Create notification for the user
    $stmt = $pdo->prepare("
        INSERT INTO notifications (user_id, message, type, created_at)
        VALUES (?, ?, 'registration_rejected', NOW())
    ");
    $stmt->execute([
        $data['user_id'],
        "Your registration has been rejected. Please contact the administrator for more information."
    ]);

    $pdo->commit();
    echo json_encode(['success' => true]);

} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
} 