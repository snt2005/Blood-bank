<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

try {
    // Get JSON data
    $jsonData = file_get_contents('php://input');
    if (!$jsonData) {
        throw new Exception('No data received');
    }

    $data = json_decode($jsonData, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('Invalid JSON data');
    }

    // Validate required fields
    $required_fields = ['username', 'email', 'password', 'name', 'address', 'city', 'contact', 'license_number', 'operating_hours'];
    foreach ($required_fields as $field) {
        if (!isset($data[$field]) || empty($data[$field])) {
            throw new Exception(ucfirst(str_replace('_', ' ', $field)) . ' is required');
        }
    }

    $pdo = getConnection();
    
    // Start transaction
    $pdo->beginTransaction();
    
    // Check if username or email already exists
    $stmt = $pdo->prepare("SELECT user_id FROM users WHERE username = ? OR email = ?");
    $stmt->execute([$data['username'], $data['email']]);
    if ($stmt->fetch()) {
        throw new Exception('Username or email already exists');
    }
    
    // Check if license number already exists
    $stmt = $pdo->prepare("SELECT hospital_id FROM hospitals WHERE license_number = ?");
    $stmt->execute([$data['license_number']]);
    if ($stmt->fetch()) {
        throw new Exception('License number already registered');
    }
    
    // Create user account
    $stmt = $pdo->prepare("
        INSERT INTO users (username, email, password, role, status, created_at) 
        VALUES (?, ?, ?, 'hospital', 'pending', CURRENT_TIMESTAMP)
    ");
    
    $hashedPassword = password_hash($data['password'], PASSWORD_DEFAULT);
    $stmt->execute([
        $data['username'],
        $data['email'],
        $hashedPassword
    ]);
    
    $userId = $pdo->lastInsertId();
    if (!$userId) {
        throw new Exception('Failed to create user account');
    }
    
    // Create hospital profile
    $stmt = $pdo->prepare("
        INSERT INTO hospitals (
            user_id, 
            name, 
            address, 
            city, 
            contact, 
            license_number,
            operating_hours,
            status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')
    ");
    
    $stmt->execute([
        $userId,
        $data['name'],
        $data['address'],
        $data['city'],
        $data['contact'],
        $data['license_number'],
        $data['operating_hours']
    ]);
    
    // Create notification for admin
    $stmt = $pdo->prepare("
        INSERT INTO notifications (
            user_id,
            title,
            message,
            type,
            is_read,
            created_at
        ) VALUES (
            (SELECT user_id FROM users WHERE role = 'admin' LIMIT 1),
            'New Hospital Registration',
            'A new hospital has registered and is pending approval.',
            'registration',
            0,
            CURRENT_TIMESTAMP
        )
    ");
    
    // Commit transaction
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'message' => 'Registration successful! Please wait for admin approval.'
    ]);

} catch (PDOException $e) {
    // Rollback transaction on error
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    if ($e->getCode() == 23000) {
        if (strpos($e->getMessage(), 'username') !== false) {
            echo json_encode(['error' => 'Username already exists']);
        } elseif (strpos($e->getMessage(), 'email') !== false) {
            echo json_encode(['error' => 'Email already exists']);
        } elseif (strpos($e->getMessage(), 'license_number') !== false) {
            echo json_encode(['error' => 'License number already registered']);
        } else {
            echo json_encode(['error' => 'A database error occurred. Please try again.']);
        }
    } else {
        echo json_encode(['error' => 'A database error occurred. Please try again.']);
    }
} catch (Exception $e) {
    // Rollback transaction on error
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    echo json_encode(['error' => $e->getMessage()]);
}
?> 