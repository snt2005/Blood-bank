<?php
require_once '../config/database.php';

try {
    $pdo = getConnection();
    
    // Check admin user
    $stmt = $pdo->prepare("SELECT * FROM users WHERE role = 'admin'");
    $stmt->execute();
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);
    
    echo "<h2>Admin Account Debug</h2>";
    
    if ($admin) {
        echo "<p>Admin account found:</p>";
        echo "<pre>";
        print_r($admin);
        echo "</pre>";
        
        // Test password verification
        $testPassword = 'admin123';
        echo "<p>Testing password verification:</p>";
        echo "<p>Stored hash: " . $admin['password'] . "</p>";
        echo "<p>Test password: " . $testPassword . "</p>";
        
        if (password_verify($testPassword, $admin['password'])) {
            echo "<p style='color: green;'>Password verification successful!</p>";
        } else {
            echo "<p style='color: red;'>Password verification failed!</p>";
            
            // Reset admin password
            $newPassword = 'admin123';
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            
            $updateStmt = $pdo->prepare("UPDATE users SET password = ? WHERE role = 'admin'");
            $updateStmt->execute([$hashedPassword]);
            
            echo "<p style='color: green;'>Admin password has been reset to: admin123</p>";
            echo "<p>New hash: " . $hashedPassword . "</p>";
            
            // Verify the new password immediately
            if (password_verify($newPassword, $hashedPassword)) {
                echo "<p style='color: green;'>New password verification successful!</p>";
            } else {
                echo "<p style='color: red;'>New password verification failed!</p>";
            }
        }
    } else {
        echo "<p style='color: red;'>No admin account found!</p>";
        
        // Create admin account
        $stmt = $pdo->prepare("
            INSERT INTO users (
                username, 
                password, 
                email, 
                role, 
                status, 
                created_at,
                full_name
            ) VALUES (
                'admin',
                ?,
                'admin@bloodbank.com',
                'admin',
                'active',
                CURRENT_TIMESTAMP,
                'System Administrator'
            )
        ");
        
        $password = 'admin123';
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        
        $stmt->execute([$hashedPassword]);
        echo "<p style='color: green;'>Admin account created successfully!</p>";
        echo "<p>Username: admin</p>";
        echo "<p>Password: admin123</p>";
        echo "<p>Hash: " . $hashedPassword . "</p>";
        
        // Verify the new password immediately
        if (password_verify($password, $hashedPassword)) {
            echo "<p style='color: green;'>New password verification successful!</p>";
        } else {
            echo "<p style='color: red;'>New password verification failed!</p>";
        }
    }
    
    // Check if admin has full_name
    if (empty($admin['full_name'])) {
        $updateStmt = $pdo->prepare("UPDATE users SET full_name = 'System Administrator' WHERE role = 'admin'");
        $updateStmt->execute();
        echo "<p style='color: green;'>Admin full name has been set.</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
}
?> 