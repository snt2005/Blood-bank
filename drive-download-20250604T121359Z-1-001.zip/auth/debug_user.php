<?php
require_once '../config/database.php';

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Get username from query parameter
$username = isset($_GET['username']) ? $_GET['username'] : '';
$role = isset($_GET['role']) ? $_GET['role'] : '';

if (empty($username) || empty($role)) {
    die("Please provide both username and role as query parameters");
}

try {
    $pdo = getConnection();
    
    // Check users table
    $stmt = $pdo->prepare("
        SELECT u.*, 
            CASE 
                WHEN u.role = 'hospital' THEN h.status
                ELSE NULL
            END as hospital_status
        FROM users u
        LEFT JOIN hospitals h ON u.user_id = h.user_id
        WHERE u.username = ? AND u.role = ?
    ");
    $stmt->execute([$username, $role]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    echo "<h2>User Details:</h2>";
    if ($user) {
        echo "<pre>";
        print_r($user);
        echo "</pre>";
        
        // Check if password is hashed
        if (password_verify('test123', $user['password'])) {
            echo "<p style='color: green;'>Password 'test123' is valid</p>";
        } else {
            echo "<p style='color: red;'>Password 'test123' is NOT valid</p>";
        }
    } else {
        echo "<p style='color: red;'>User not found in database</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
}
?> 