<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../config/database.php';

header('Content-Type: application/json');

// Test database connection
try {
    $pdo = getConnection();
    if (!$pdo) {
        throw new Exception("Database connection failed");
    }
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => 'Database connection error: ' . $e->getMessage()]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Parse JSON input
    $data = json_decode(file_get_contents('php://input'), true);

    // Debug: log received data
    file_put_contents(__DIR__.'/debug_recipient.txt', print_r($data, true));

    // Validate required fields
    $required_fields = ['username', 'password', 'name', 'age', 'blood_group', 'contact', 'city', 'address'];
    $missing_fields = [];
    foreach ($required_fields as $field) {
        if (!isset($data[$field]) || empty($data[$field])) {
            $missing_fields[] = $field;
        }
    }

    if (!empty($missing_fields)) {
        echo json_encode(['status' => 'error', 'message' => 'Missing required fields: ' . implode(', ', $missing_fields)]);
        exit;
    }

    try {
        $pdo->beginTransaction();

        // Check if username or email already exists
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$data['username'], $data['email']]);
        if ($stmt->fetchColumn() > 0) {
            echo json_encode(['status' => 'error', 'message' => 'Username or email already exists']);
            exit;
        }

        // Insert into users table
        $stmt = $pdo->prepare("INSERT INTO users (username, password, role, email, status) VALUES (?, ?, 'recipient', ?, 'active')");
        $hashedPassword = password_hash($data['password'], PASSWORD_DEFAULT);
        $stmt->execute([$data['username'], $hashedPassword, $data['email']]);
        $userId = $pdo->lastInsertId();

        // Insert into recipients table
        $stmt = $pdo->prepare("INSERT INTO recipients (user_id, name, age, blood_group, contact, city, address, medical_condition) 
                              VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $userId,
            $data['name'],
            $data['age'],
            $data['blood_group'],
            $data['contact'],
            $data['city'],
            $data['address'],
            isset($data['medical_condition']) && $data['medical_condition'] !== null ? $data['medical_condition'] : ''
        ]);

        $pdo->commit();
        echo json_encode(['success' => true, 'message' => 'Registration successful']);
    } catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        // Log the error to a file for debugging
        file_put_contents(__DIR__.'/debug_recipient_error.txt', $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Registration failed: ' . $e->getMessage()]);
    }
}
?> 