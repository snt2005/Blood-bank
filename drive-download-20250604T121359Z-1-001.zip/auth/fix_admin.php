<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include database configuration
require_once '../config/database.php';

try {
    // Test database connection
    $pdo = getConnection();
    echo "<p style='color: green;'>Database connection successful!</p>";

    // Delete existing admin account if any
    $stmt = $pdo->prepare("DELETE FROM users WHERE role = 'admin'");
    $stmt->execute();
    echo "<p>Cleaned up any existing admin accounts</p>";

    // Create new admin account
    $stmt = $pdo->prepare("
        INSERT INTO users (
            username,
            password,
            email,
            role,
            status,
            full_name,
            created_at
        ) VALUES (
            'admin',
            ?,
            'admin@bloodbank.com',
            'admin',
            'active',
            'System Administrator',
            CURRENT_TIMESTAMP
        )
    ");

    // Create password hash
    $password = 'admin123';
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    
    // Insert admin account
    $stmt->execute([$hashedPassword]);
    echo "<p style='color: green;'>Admin account created successfully!</p>";

    // Verify the account was created
    $checkStmt = $pdo->prepare("SELECT * FROM users WHERE role = 'admin'");
    $checkStmt->execute();
    $admin = $checkStmt->fetch(PDO::FETCH_ASSOC);

    if ($admin) {
        echo "<h3>Admin Account Details:</h3>";
        echo "<pre>";
        print_r($admin);
        echo "</pre>";

        // Test password verification
        if (password_verify($password, $admin['password'])) {
            echo "<p style='color: green;'>Password verification successful!</p>";
        } else {
            echo "<p style='color: red;'>Password verification failed!</p>";
        }

        echo "<h3>Login Credentials:</h3>";
        echo "<p>Username: admin</p>";
        echo "<p>Password: admin123</p>";
        echo "<p>Role: admin</p>";
    } else {
        echo "<p style='color: red;'>Failed to create admin account!</p>";
    }

} catch (PDOException $e) {
    echo "<p style='color: red;'>Database Error: " . $e->getMessage() . "</p>";
} catch (Exception $e) {
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
}
?> 