<?php
require_once '../config/database.php';

try {
    $pdo = getConnection();
    
    // Check if admin user exists
    $stmt = $pdo->prepare("SELECT * FROM users WHERE role = 'admin'");
    $stmt->execute();
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$admin) {
        // Create admin user if it doesn't exist
        $stmt = $pdo->prepare("
            INSERT INTO users (
                username, 
                password, 
                email, 
                role, 
                status, 
                created_at
            ) VALUES (
                'admin',
                ?,
                'admin@bloodbank.com',
                'admin',
                'active',
                CURRENT_TIMESTAMP
            )
        ");
        
        // Create hashed password
        $password = 'admin123'; // Default admin password
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        
        $stmt->execute([$hashedPassword]);
        echo "Admin account created successfully!<br>";
        echo "Username: admin<br>";
        echo "Password: admin123<br>";
    } else {
        // Update admin status to active if it exists
        $stmt = $pdo->prepare("UPDATE users SET status = 'active' WHERE role = 'admin'");
        $stmt->execute();
        echo "Admin account already exists and has been set to active.<br>";
    }
    
    echo "You can now log in as admin using these credentials.";
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?> 