<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Get JSON data
$data = json_decode(file_get_contents('php://input'), true);

if (!$data) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON data']);
    exit;
}

// Validate required fields
$required_fields = ['username', 'password', 'email', 'name', 'age', 'weight', 'blood_group', 'contact', 'city'];
foreach ($required_fields as $field) {
    if (empty($data[$field])) {
        http_response_code(400);
        echo json_encode(['error' => ucfirst($field) . ' is required']);
        exit;
    }
}

// Validate email format
if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid email format']);
    exit;
}

// Validate age
if (!is_numeric($data['age']) || $data['age'] < 18) {
    http_response_code(400);
    echo json_encode(['error' => 'Age must be 18 or older']);
    exit;
}

// Validate weight
if (!is_numeric($data['weight']) || $data['weight'] < 50) {
    http_response_code(400);
    echo json_encode(['error' => 'Weight must be at least 50 kg']);
    exit;
}

// Validate blood group
$valid_blood_groups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
if (!in_array($data['blood_group'], $valid_blood_groups)) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid blood group']);
    exit;
}

try {
    $pdo = getConnection();
    $pdo->beginTransaction();

    // Check if username or email already exists
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ? OR email = ?");
    $stmt->execute([$data['username'], $data['email']]);
    if ($stmt->fetchColumn() > 0) {
        $pdo->rollBack();
        http_response_code(400);
        echo json_encode(['error' => 'Username or email already exists']);
        exit;
    }

    // Insert into users table
    $stmt = $pdo->prepare("
        INSERT INTO users (username, password, email, role, status) 
        VALUES (?, ?, ?, 'donor', 'active')
    ");
    $stmt->execute([
        $data['username'],
        password_hash($data['password'], PASSWORD_DEFAULT),
        $data['email']
    ]);
    $user_id = $pdo->lastInsertId();

    // Insert into donors table
    $stmt = $pdo->prepare("
        INSERT INTO donors (
            user_id, name, age, weight, blood_group, 
            contact, city, address, medical_conditions, medications
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([
        $user_id,
        $data['name'],
        $data['age'],
        $data['weight'],
        $data['blood_group'],
        $data['contact'],
        $data['city'],
        $data['address'] ?? null,
        $data['medical_conditions'] ?? null,
        $data['medications'] ?? null
    ]);
    $donor_id = $pdo->lastInsertId();

    // Create welcome notification
    $stmt = $pdo->prepare("
        INSERT INTO notifications (user_id, title, message, type)
        VALUES (?, 'Welcome to Blood Bank!', 'Thank you for registering as a donor. Your account is now active.', 'success')
    ");
    $stmt->execute([$user_id]);

    $pdo->commit();

    // Set session variables
    $_SESSION['user_id'] = $user_id;
    $_SESSION['username'] = $data['username'];
    $_SESSION['role'] = 'donor';
    $_SESSION['entity_id'] = $donor_id;
    $_SESSION['full_name'] = $data['name'];

    echo json_encode([
        'success' => true,
        'message' => 'Registration successful',
        'user' => [
            'user_id' => $user_id,
            'username' => $data['username'],
            'email' => $data['email'],
            'role' => 'donor',
            'entity_id' => $donor_id,
            'full_name' => $data['name']
        ]
    ]);

} catch (PDOException $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log("Registration error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Database error occurred']);
} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log("Registration error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'An unexpected error occurred']);
}
?> 