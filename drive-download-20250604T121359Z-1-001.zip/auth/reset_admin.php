<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include database configuration
require_once '../config/database.php';

try {
    // Test database connection
    $pdo = getConnection();
    echo "<p style='color: green;'>Database connection successful!</p>";

    // First, let's see what's in the database
    $checkStmt = $pdo->prepare("SELECT * FROM users WHERE role = 'admin'");
    $checkStmt->execute();
    $existingAdmin = $checkStmt->fetch(PDO::FETCH_ASSOC);

    if ($existingAdmin) {
        echo "<h3>Existing Admin Account:</h3>";
        echo "<pre>";
        print_r($existingAdmin);
        echo "</pre>";
    }

    // Delete existing admin account
    $deleteStmt = $pdo->prepare("DELETE FROM users WHERE role = 'admin'");
    $deleteStmt->execute();
    echo "<p>Deleted existing admin account</p>";

    // Create new password hash
    $password = 'admin123';
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    
    echo "<h3>Password Information:</h3>";
    echo "<p>Plain password: " . $password . "</p>";
    echo "<p>Hashed password: " . $hashedPassword . "</p>";

    // Create new admin account
    $stmt = $pdo->prepare("
        INSERT INTO users (
            username,
            password,
            email,
            role,
            status,
            full_name,
            created_at
        ) VALUES (
            'admin',
            ?,
            'admin@bloodbank.com',
            'admin',
            'active',
            'System Administrator',
            CURRENT_TIMESTAMP
        )
    ");

    // Insert admin account
    $stmt->execute([$hashedPassword]);
    echo "<p style='color: green;'>New admin account created!</p>";

    // Verify the account was created
    $verifyStmt = $pdo->prepare("SELECT * FROM users WHERE role = 'admin'");
    $verifyStmt->execute();
    $newAdmin = $verifyStmt->fetch(PDO::FETCH_ASSOC);

    if ($newAdmin) {
        echo "<h3>New Admin Account Details:</h3>";
        echo "<pre>";
        print_r($newAdmin);
        echo "</pre>";

        // Test password verification
        echo "<h3>Testing Password Verification:</h3>";
        echo "<p>Stored hash: " . $newAdmin['password'] . "</p>";
        echo "<p>Testing with password: " . $password . "</p>";

        if (password_verify($password, $newAdmin['password'])) {
            echo "<p style='color: green; font-size: 20px;'>Password verification SUCCESSFUL!</p>";
        } else {
            echo "<p style='color: red; font-size: 20px;'>Password verification FAILED!</p>";
        }

        echo "<h3>Login Instructions:</h3>";
        echo "<p>1. Go to the login page</p>";
        echo "<p>2. Enter these exact credentials:</p>";
        echo "<ul>";
        echo "<li>Username: <strong>admin</strong></li>";
        echo "<li>Password: <strong>admin123</strong></li>";
        echo "<li>Role: <strong>admin</strong></li>";
        echo "</ul>";
        echo "<p>3. Make sure there are no extra spaces before or after the username/password</p>";
    } else {
        echo "<p style='color: red;'>Failed to create admin account!</p>";
    }

} catch (PDOException $e) {
    echo "<p style='color: red;'>Database Error: " . $e->getMessage() . "</p>";
} catch (Exception $e) {
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
}
?> 