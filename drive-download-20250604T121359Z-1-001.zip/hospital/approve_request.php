<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Check if user is logged in and is a hospital
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'hospital') {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized access']);
    exit;
}

// Get JSON data
$data = json_decode(file_get_contents('php://input'), true);

if (!$data) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON data']);
    exit;
}

// Validate required fields
if (empty($data['request_id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Request ID is required']);
    exit;
}

try {
    $pdo = getConnection();
    $pdo->beginTransaction();
    
    // Get hospital ID
    $stmt = $pdo->prepare("SELECT hospital_id FROM hospitals WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $hospital = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$hospital) {
        $pdo->rollBack();
        http_response_code(404);
        echo json_encode(['error' => 'Hospital not found']);
        exit;
    }
    
    // Verify request exists and belongs to hospital
    $stmt = $pdo->prepare("
        SELECT br.request_id, br.recipient_id, br.blood_group, br.units, br.required_by, br.status
        FROM blood_requests br
        WHERE br.request_id = ?
        AND br.hospital_id = ?
        AND br.status = 'pending'
    ");
    $stmt->execute([$data['request_id'], $hospital['hospital_id']]);
    $request = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$request) {
        $pdo->rollBack();
        http_response_code(404);
        echo json_encode(['error' => 'Request not found or cannot be approved']);
        exit;
    }
    
    // Check if required by date is in the future
    $required_by = new DateTime($request['required_by']);
    $today = new DateTime();
    if ($required_by < $today) {
        $pdo->rollBack();
        http_response_code(400);
        echo json_encode(['error' => 'Cannot approve requests that are past their required date']);
        exit;
    }
    
    // Check if enough blood units are available
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as available_units
        FROM blood_units
        WHERE hospital_id = ?
        AND blood_group = ?
        AND status = 'available'
        AND expiry_date > ?
    ");
    $stmt->execute([$hospital['hospital_id'], $request['blood_group'], $request['required_by']]);
    $available = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($available['available_units'] < $request['units']) {
        $pdo->rollBack();
        http_response_code(400);
        echo json_encode(['error' => 'Not enough blood units available']);
        exit;
    }
    
    // Update request status
    $stmt = $pdo->prepare("
        UPDATE blood_requests 
        SET status = 'approved' 
        WHERE request_id = ?
    ");
    $stmt->execute([$data['request_id']]);
    
    // Get recipient information for notification
    $stmt = $pdo->prepare("
        SELECT r.user_id, r.name
        FROM recipients r
        WHERE r.recipient_id = ?
    ");
    $stmt->execute([$request['recipient_id']]);
    $recipient = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Create notification for the recipient
    $stmt = $pdo->prepare("
        INSERT INTO notifications (user_id, title, message, type)
        VALUES (?, 'Blood Request Approved', 'Your blood request has been approved by the hospital.', 'success')
    ");
    $stmt->execute([$recipient['user_id']]);
    
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'message' => 'Blood request approved successfully'
    ]);

} catch (PDOException $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log("Approve request error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Database error occurred']);
} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log("Approve request error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'An unexpected error occurred']);
}
?> 