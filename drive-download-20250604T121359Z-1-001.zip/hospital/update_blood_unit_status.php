<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

// Check if user is logged in and is a hospital
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'hospital') {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Unauthorized access']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

// Validate required fields
if (!isset($data['unit_id']) || empty($data['status'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Unit ID and status are required']);
    exit;
}

// Validate status value
$valid_statuses = ['available', 'reserved', 'used', 'expired', 'in-transit', 'discarded'];
if (!in_array($data['status'], $valid_statuses)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid status value']);
    exit;
}

try {
    $pdo = getConnection();
    
    // Get hospital ID from the session user
    $stmt = $pdo->prepare("SELECT hospital_id FROM hospitals WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $hospital = $stmt->fetch();
    
    if (!$hospital) {
        http_response_code(404);
        echo json_encode(['success' => false, 'error' => 'Hospital not found']);
        exit;
    }
    
    // Verify that the blood unit exists and belongs to this hospital
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM blood_units WHERE unit_id = ? AND hospital_id = ?");
    $stmt->execute([$data['unit_id'], $hospital['hospital_id']]);
    
    if ($stmt->fetchColumn() === 0) {
        http_response_code(404);
        echo json_encode(['success' => false, 'error' => 'Blood unit not found or does not belong to this hospital']);
        exit;
    }

    // Update the blood unit status
    $stmt = $pdo->prepare("UPDATE blood_units SET status = ? WHERE unit_id = ?");
    $stmt->execute([$data['status'], $data['unit_id']]);

    echo json_encode(['success' => true, 'message' => 'Blood unit status updated successfully']);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?> 