<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Check if user is logged in and is a hospital
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'hospital') {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized access']);
    exit;
}

// Get JSON data
$data = json_decode(file_get_contents('php://input'), true);

if (!$data) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON data']);
    exit;
}

// Validate required fields
if (empty($data['donor_id']) || empty($data['blood_group']) || empty($data['volume']) || empty($data['expiry_date'])) {
    http_response_code(400);
    echo json_encode(['error' => 'All fields are required']);
    exit;
}

// Validate blood group
$valid_blood_groups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
if (!in_array($data['blood_group'], $valid_blood_groups)) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid blood group']);
    exit;
}

// Validate volume
if (!is_numeric($data['volume']) || $data['volume'] < 350 || $data['volume'] > 450) {
    http_response_code(400);
    echo json_encode(['error' => 'Volume must be between 350 and 450 ml']);
    exit;
}

// Validate expiry date
$expiry_date = new DateTime($data['expiry_date']);
$today = new DateTime();
if ($expiry_date <= $today) {
    http_response_code(400);
    echo json_encode(['error' => 'Expiry date must be in the future']);
    exit;
}

try {
    $pdo = getConnection();
    $pdo->beginTransaction();
    
    // Get hospital ID
    $stmt = $pdo->prepare("SELECT hospital_id FROM hospitals WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $hospital = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$hospital) {
        $pdo->rollBack();
        http_response_code(404);
        echo json_encode(['error' => 'Hospital not found']);
        exit;
    }
    
    // Verify donor exists and has completed appointment today
    $stmt = $pdo->prepare("
        SELECT d.donor_id, d.blood_group
        FROM donors d
        JOIN appointments a ON d.donor_id = a.donor_id
        WHERE d.donor_id = ?
        AND a.hospital_id = ?
        AND a.status = 'completed'
        AND a.appointment_date = CURRENT_DATE
        AND NOT EXISTS (
            SELECT 1 
            FROM blood_units bu 
            WHERE bu.donor_id = d.donor_id 
            AND bu.collection_date = CURRENT_DATE
        )
    ");
    $stmt->execute([$data['donor_id'], $hospital['hospital_id']]);
    $donor = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$donor) {
        $pdo->rollBack();
        http_response_code(400);
        echo json_encode(['error' => 'Invalid donor or no completed appointment found']);
        exit;
    }
    
    // Verify blood group matches donor
    if ($donor['blood_group'] !== $data['blood_group']) {
        $pdo->rollBack();
        http_response_code(400);
        echo json_encode(['error' => 'Blood group does not match donor']);
        exit;
    }
    
    // Insert blood unit
    $stmt = $pdo->prepare("
        INSERT INTO blood_units (
            donor_id, hospital_id, blood_group, volume, 
            collection_date, expiry_date, status, notes
        ) VALUES (?, ?, ?, ?, CURRENT_DATE, ?, 'available', ?)
    ");
    
    $stmt->execute([
        $data['donor_id'],
        $hospital['hospital_id'],
        $data['blood_group'],
        $data['volume'],
        $data['expiry_date'],
        $data['notes'] ?? null
    ]);
    
    $unit_id = $pdo->lastInsertId();
    
    // Create notification for the hospital
    $stmt = $pdo->prepare("
        INSERT INTO notifications (user_id, title, message, type)
        VALUES (?, 'New Blood Unit Added', 'A new blood unit has been added to your inventory.', 'success')
    ");
    $stmt->execute([$_SESSION['user_id']]);
    
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'message' => 'Blood unit added successfully',
        'unit_id' => $unit_id
    ]);

} catch (PDOException $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log("Add blood error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Database error occurred']);
} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log("Add blood error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'An unexpected error occurred']);
}
?> 