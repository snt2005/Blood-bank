<?php
session_start();
require_once '../config/database.php';
header('Content-Type: application/json');

// Check if user is logged in and is a hospital
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'hospital') {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Unauthorized access']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

// Validate required fields
$required = ['blood_group', 'type', 'donation_date', 'expiry_date'];
foreach ($required as $field) {
    if (empty($data[$field])) {
        echo json_encode(['success' => false, 'error' => ucfirst($field) . ' is required']);
        exit;
    }
}

try {
    $pdo = getConnection();
    // Get hospital ID
    $stmt = $pdo->prepare("SELECT hospital_id FROM hospitals WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $hospital = $stmt->fetch();
    if (!$hospital) {
        echo json_encode(['success' => false, 'error' => 'Hospital not found']);
        exit;
    }

    // Insert blood unit
    $stmt = $pdo->prepare("
        INSERT INTO blood_units (
            hospital_id, blood_group, component_type, donor_id, donation_date, expiry_date, status
        ) VALUES (?, ?, ?, ?, ?, ?, 'available')
    ");
    $stmt->execute([
        $hospital['hospital_id'],
        $data['blood_group'],
        $data['type'],
        $data['donor_id'] !== '' ? $data['donor_id'] : null,
        $data['donation_date'],
        $data['expiry_date']
    ]);

    echo json_encode(['success' => true]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
} 