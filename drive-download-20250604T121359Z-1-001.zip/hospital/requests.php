<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is a hospital
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'hospital') {
    header('Location: ../login.html');
    exit;
}

$pdo = getConnection();

// Get hospital ID and name
$stmt = $pdo->prepare("SELECT hospital_id, name FROM hospitals WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$hospital = $stmt->fetch();
if (!$hospital) {
    die('Hospital not found.');
}

$error = null;
$requests = [];

try {
    // Get blood requests for this hospital
    $stmt = $pdo->prepare("
        SELECT 
            br.request_id,
            br.request_date,
            br.blood_group,
            br.component_type,
            br.units_required,
            br.required_date,
            br.status,
            br.priority,
            r.name as recipient_name
        FROM blood_requests br
        JOIN recipients r ON br.recipient_id = r.recipient_id
        WHERE br.hospital_id = ?
        AND br.status IN ('pending', 'approved') -- Display pending and approved requests
        ORDER BY 
            CASE 
                WHEN br.priority = 'emergency' THEN 1
                WHEN br.priority = 'urgent' THEN 2
                ELSE 3
            END,
            br.request_date DESC
    ");
    
    $stmt->execute([$hospital['hospital_id']]);
    $requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    error_log("Hospital requests error: " . $e->getMessage());
    $error = "An error occurred while loading blood requests.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blood Requests - <?php echo htmlspecialchars($hospital['name']); ?> | Blood Bank</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.2/font/bootstrap-icons.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="../hospital_dashboard.php">Dashboard</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="blood_units.php">Manage Inventory</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="requests.php">Blood Requests</a>
                    </li>
                </ul>
                 <div class="d-flex align-items-center">
                    <div class="dropdown">
                        <button class="btn btn-light dropdown-toggle" type="button" data-bs-toggle="dropdown">
                            <i class="bi bi-person-circle"></i> <?php echo htmlspecialchars($hospital['name']); ?>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="profile.php">Profile</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="../auth/logout.php">Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <h2>Blood Requests</h2>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body">
                <?php if (empty($requests)): ?>
                    <p class="text-center">No blood requests found.</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>Request ID</th>
                                    <th>Date</th>
                                    <th>Blood Group</th>
                                     <th>Component Type</th>
                                    <th>Units</th>
                                    <th>Required By</th>
                                    <th>Status</th>
                                    <th>Priority</th>
                                    <th>Recipient</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($requests as $request): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($request['request_id']); ?></td>
                                        <td><?php echo htmlspecialchars(date('Y-m-d H:i', strtotime($request['request_date']))); ?></td>
                                        <td><?php echo htmlspecialchars($request['blood_group']); ?></td>
                                         <td><?php echo htmlspecialchars($request['component_type'] ?? 'N/A'); ?></td>
                                        <td><?php echo htmlspecialchars($request['units_required']); ?></td>
                                        <td><?php echo htmlspecialchars(date('Y-m-d', strtotime($request['required_date']))); ?></td>
                                        <td>
                                            <span class="badge bg-<?php 
                                                echo $request['status'] === 'pending' ? 'warning' : 
                                                     ($request['status'] === 'approved' ? 'success' : 'secondary'); 
                                            ?>">
                                                <?php echo htmlspecialchars(ucfirst($request['status'])); ?>
                                            </span>
                                        </td>
                                         <td>
                                            <span class="badge bg-<?php 
                                                echo $request['priority'] === 'emergency' ? 'danger' : 
                                                     ($request['priority'] === 'urgent' ? 'warning' : 'info'); 
                                            ?>">
                                                <?php echo htmlspecialchars(ucfirst($request['priority'] ?? 'Normal')); ?>
                                            </span>
                                        </td>
                                        <td><?php echo htmlspecialchars($request['recipient_name']); ?></td>
                                        <td>
                                            <?php if ($request['status'] === 'pending'): ?>
                                                <button class="btn btn-sm btn-success approve-btn" data-request-id="<?php echo $request['request_id']; ?>">Approve</button>
                                                <button class="btn btn-sm btn-danger reject-btn" data-request-id="<?php echo $request['request_id']; ?>">Reject</button>
                                            <?php endif; ?>
                                             <!-- Add other actions like View Details if needed -->
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                     <!-- Add pagination or more advanced filtering/sorting here if needed -->
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // JavaScript for Approve/Reject actions (AJAX)
        document.querySelectorAll('.approve-btn').forEach(button => {
            button.addEventListener('click', function() {
                const requestId = this.dataset.requestId;
                updateRequestStatus(requestId, 'approved');
            });
        });

        document.querySelectorAll('.reject-btn').forEach(button => {
            button.addEventListener('click', function() {
                const requestId = this.dataset.requestId;
                 updateRequestStatus(requestId, 'rejected');
            });
        });

        function updateRequestStatus(requestId, status) {
            if (confirm(`Are you sure you want to ${status} this request?`)) {
                fetch('update_request_status.php', { // You will need to create this backend script
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ request_id: requestId, status: status })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert(`Request ${status} successfully!`);
                        location.reload(); // Reload the page to show updated status
                    } else {
                        alert(data.error || 'Failed to update request status.');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred while updating the request status.');
                });
            }
        }

    </script>
</body>
</html> 