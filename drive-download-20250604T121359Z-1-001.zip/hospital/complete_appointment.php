<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Check if user is logged in and is a hospital
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'hospital') {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized access']);
    exit;
}

// Get JSON data
$data = json_decode(file_get_contents('php://input'), true);

if (!$data) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON data']);
    exit;
}

// Validate required fields
if (empty($data['appointment_id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Appointment ID is required']);
    exit;
}

try {
    $pdo = getConnection();
    $pdo->beginTransaction();
    
    // Get hospital ID
    $stmt = $pdo->prepare("SELECT hospital_id FROM hospitals WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $hospital = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$hospital) {
        $pdo->rollBack();
        http_response_code(404);
        echo json_encode(['error' => 'Hospital not found']);
        exit;
    }
    
    // Verify appointment exists and belongs to hospital
    $stmt = $pdo->prepare("
        SELECT a.appointment_id, a.donor_id, a.appointment_date, a.status
        FROM appointments a
        WHERE a.appointment_id = ?
        AND a.hospital_id = ?
        AND a.status = 'scheduled'
    ");
    $stmt->execute([$data['appointment_id'], $hospital['hospital_id']]);
    $appointment = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$appointment) {
        $pdo->rollBack();
        http_response_code(404);
        echo json_encode(['error' => 'Appointment not found or cannot be completed']);
        exit;
    }
    
    // Check if appointment is today
    $appointment_date = new DateTime($appointment['appointment_date']);
    $today = new DateTime();
    if ($appointment_date->format('Y-m-d') !== $today->format('Y-m-d')) {
        $pdo->rollBack();
        http_response_code(400);
        echo json_encode(['error' => 'Can only complete appointments scheduled for today']);
        exit;
    }
    
    // Update appointment status
    $stmt = $pdo->prepare("
        UPDATE appointments 
        SET status = 'completed' 
        WHERE appointment_id = ?
    ");
    $stmt->execute([$data['appointment_id']]);
    
    // Get donor information for notification
    $stmt = $pdo->prepare("
        SELECT d.user_id, d.name
        FROM donors d
        WHERE d.donor_id = ?
    ");
    $stmt->execute([$appointment['donor_id']]);
    $donor = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Create notification for the donor
    $stmt = $pdo->prepare("
        INSERT INTO notifications (user_id, title, message, type)
        VALUES (?, 'Appointment Completed', 'Your blood donation appointment has been completed successfully.', 'success')
    ");
    $stmt->execute([$donor['user_id']]);
    
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'message' => 'Appointment completed successfully'
    ]);

} catch (PDOException $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log("Complete appointment error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Database error occurred']);
} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log("Complete appointment error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'An unexpected error occurred']);
}
?> 