<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

// Check if user is logged in and is a hospital
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'hospital') {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized access']);
    exit;
}

try {
    $pdo = getConnection();
    
    // Get hospital ID
    $stmt = $pdo->prepare("SELECT hospital_id FROM hospitals WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $hospital = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$hospital) {
        http_response_code(404);
        echo json_encode(['error' => 'Hospital not found']);
        exit;
    }
    
    // Get available donors (those who have completed appointments)
    $stmt = $pdo->prepare("
        SELECT DISTINCT
            d.donor_id,
            d.name,
            d.blood_group
        FROM donors d
        JOIN appointments a ON d.donor_id = a.donor_id
        WHERE a.hospital_id = ?
        AND a.status = 'completed'
        AND a.appointment_date = CURRENT_DATE
        AND NOT EXISTS (
            SELECT 1 
            FROM blood_units bu 
            WHERE bu.donor_id = d.donor_id 
            AND bu.collection_date = CURRENT_DATE
        )
        ORDER BY d.name
    ");
    
    $stmt->execute([$hospital['hospital_id']]);
    $donors = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'donors' => $donors
    ]);

} catch (PDOException $e) {
    error_log("Donors error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Database error occurred']);
} catch (Exception $e) {
    error_log("Donors error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'An unexpected error occurred']);
}
?> 