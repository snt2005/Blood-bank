<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

// Check if user is logged in and is a hospital
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'hospital') {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized access']);
    exit;
}

try {
    $pdo = getConnection();
    
    // Get hospital ID
    $stmt = $pdo->prepare("SELECT hospital_id FROM hospitals WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $hospital = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$hospital) {
        http_response_code(404);
        echo json_encode(['error' => 'Hospital not found']);
        exit;
    }
    
    // Get blood inventory summary
    $stmt = $pdo->prepare("
        SELECT 
            blood_group,
            COUNT(*) as units_available,
            MAX(collection_date) as last_updated,
            CASE 
                WHEN COUNT(*) > 10 THEN 'sufficient'
                WHEN COUNT(*) > 5 THEN 'moderate'
                ELSE 'low'
            END as status
        FROM blood_units
        WHERE hospital_id = ? 
        AND status = 'available'
        AND expiry_date > CURRENT_DATE
        GROUP BY blood_group
        ORDER BY blood_group
    ");
    
    $stmt->execute([$hospital['hospital_id']]);
    $inventory = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'inventory' => $inventory
    ]);

} catch (PDOException $e) {
    error_log("Inventory error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Database error occurred']);
} catch (Exception $e) {
    error_log("Inventory error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'An unexpected error occurred']);
}
?> 