<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

// Check if user is logged in and is a hospital
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'hospital') {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Unauthorized access']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

// Validate required fields
if (!isset($data['counts']) || !is_array($data['counts'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid data format']);
    exit;
}

try {
    $pdo = getConnection();
    
    // Get hospital ID from the session user
    $stmt = $pdo->prepare("SELECT hospital_id FROM hospitals WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $hospital = $stmt->fetch();
    
    if (!$hospital) {
        http_response_code(404);
        echo json_encode(['success' => false, 'error' => 'Hospital not found']);
        exit;
    }
    
    $hospital_id = $hospital['hospital_id'];
    
    $pdo->beginTransaction();

    // Iterate through the received counts and update/insert into the database
    foreach ($data['counts'] as $bloodGroup => $componentCounts) {
        foreach ($componentCounts as $componentType => $count) {
            // Ensure count is a non-negative integer
            $count = max(0, intval($count));

            // Check if the entry already exists
            $stmt = $pdo->prepare("
                SELECT COUNT(*) FROM hospital_inventory_counts 
                WHERE hospital_id = ? AND blood_group = ? AND component_type = ?
            ");
            $stmt->execute([$hospital_id, $bloodGroup, $componentType]);
            $exists = $stmt->fetchColumn();

            if ($exists) {
                // Update existing entry
                $stmt = $pdo->prepare("
                    UPDATE hospital_inventory_counts 
                    SET available_count = ? 
                    WHERE hospital_id = ? AND blood_group = ? AND component_type = ?
                ");
                $stmt->execute([$count, $hospital_id, $bloodGroup, $componentType]);
            } else {
                // Insert new entry
                $stmt = $pdo->prepare("
                    INSERT INTO hospital_inventory_counts 
                    (hospital_id, blood_group, component_type, available_count) 
                    VALUES (?, ?, ?, ?)
                ");
                $stmt->execute([$hospital_id, $bloodGroup, $componentType, $count]);
            }
        }
    }

    $pdo->commit();

    echo json_encode(['success' => true, 'message' => 'Inventory counts updated successfully']);

} catch (Exception $e) {
    $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?> 