<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is a donor
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'donor') {
    header('Location: ../login.html');
    exit;
}

try {
    $pdo = getConnection();
    
    // Get donor information
    $stmt = $pdo->prepare("
        SELECT d.*, u.email, u.username
        FROM donors d
        JOIN users u ON d.user_id = u.user_id
        WHERE d.user_id = ?
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $donor = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$donor) {
        throw new Exception('Donor not found');
    }

    // Get donation history
    $stmt = $pdo->prepare("
        SELECT 
            bu.unit_id,
            bu.donation_date,
            bu.blood_group,
            bu.volume_ml as quantity,
            bu.status,
            bu.component_type,
            h.name as hospital_name
        FROM blood_units bu
        LEFT JOIN hospitals h ON bu.hospital_id = h.hospital_id
        WHERE bu.donor_id = ?
        ORDER BY bu.donation_date DESC
    ");
    $stmt->execute([$donor['donor_id']]);
    $donations = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Get past appointments
    $stmt = $pdo->prepare("
        SELECT 
            a.appointment_id,
            a.appointment_date,
            a.appointment_time,
            a.status,
            h.name as hospital_name
        FROM appointments a
        JOIN hospitals h ON a.hospital_id = h.hospital_id
        WHERE a.donor_id = ? 
        AND a.appointment_date < CURDATE()
        ORDER BY a.appointment_date DESC, a.appointment_time DESC
    ");
    $stmt->execute([$donor['donor_id']]);
    $pastAppointments = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    error_log("Donation history error: " . $e->getMessage());
    $error = "An error occurred while loading the donation history: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donation History - Blood Bank Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="#">Blood Bank Management System</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../donor_dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="appointments.php">Appointments</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="history.php">Donation History</a>
                    </li>
                </ul>
                <div class="d-flex">
                    <a href="../auth/logout.php" class="btn btn-light">Logout</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <div class="row">
            <!-- Donation History -->
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Donation History</h5>
                        <?php if (empty($donations)): ?>
                            <p>No donations have been made yet.</p>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>Blood Group</th>
                                            <th>Type</th>
                                            <th>Volume</th>
                                            <th>Hospital</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($donations as $donation): ?>
                                            <tr>
                                                <td><?php echo date('M d, Y', strtotime($donation['donation_date'])); ?></td>
                                                <td><?php echo htmlspecialchars($donation['blood_group']); ?></td>
                                                <td><?php echo htmlspecialchars($donation['component_type']); ?></td>
                                                <td><?php echo htmlspecialchars($donation['quantity']); ?> ml</td>
                                                <td><?php echo htmlspecialchars($donation['hospital_name']); ?></td>
                                                <td>
                                                    <span class="badge bg-<?php 
                                                        echo $donation['status'] === 'available' ? 'success' : 
                                                            ($donation['status'] === 'used' ? 'warning' : 
                                                            ($donation['status'] === 'expired' ? 'danger' : 
                                                            ($donation['status'] === 'reserved' ? 'info' : 'secondary'))); 
                                                    ?>">
                                                        <?php echo ucfirst($donation['status']); ?>
                                                    </span>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Past Appointments -->
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Past Appointments</h5>
                        <?php if (empty($pastAppointments)): ?>
                            <p>No past appointments found.</p>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>Time</th>
                                            <th>Hospital</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($pastAppointments as $appointment): ?>
                                            <tr>
                                                <td><?php echo date('M d, Y', strtotime($appointment['appointment_date'])); ?></td>
                                                <td><?php echo date('h:i A', strtotime($appointment['appointment_time'])); ?></td>
                                                <td><?php echo htmlspecialchars($appointment['hospital_name']); ?></td>
                                                <td>
                                                    <span class="badge bg-<?php 
                                                        echo $appointment['status'] === 'completed' ? 'success' : 
                                                            ($appointment['status'] === 'cancelled' ? 'danger' : 
                                                            ($appointment['status'] === 'no_show' ? 'warning' : 'secondary')); 
                                                    ?>">
                                                        <?php echo ucfirst($appointment['status']); ?>
                                                    </span>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 