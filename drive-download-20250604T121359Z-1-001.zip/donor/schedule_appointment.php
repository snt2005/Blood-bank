<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

// Check if user is logged in and is a donor
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'donor') {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized access']);
    exit;
}

// Get JSON data
$data = json_decode(file_get_contents('php://input'), true);

// Validate required fields
if (!isset($data['hospital_id']) || !isset($data['appointment_date']) || !isset($data['appointment_time'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing required fields']);
    exit;
}

try {
    $pdo = getConnection();
    
    // Start transaction
    $pdo->beginTransaction();
    
    // Get donor ID
    $stmt = $pdo->prepare("SELECT donor_id FROM donors WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $donor = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$donor) {
        throw new Exception('Donor not found');
    }
    
    // Check if hospital exists and is active
    $stmt = $pdo->prepare("SELECT hospital_id FROM hospitals WHERE hospital_id = ? AND status = 'active'");
    $stmt->execute([$data['hospital_id']]);
    if (!$stmt->fetch()) {
        throw new Exception('Invalid or inactive hospital');
    }
    
    // Check if the appointment slot is available
    $stmt = $pdo->prepare("
        SELECT COUNT(*) 
        FROM appointments 
        WHERE hospital_id = ? 
        AND appointment_date = ? 
        AND appointment_time = ? 
        AND status != 'cancelled'
    ");
    $stmt->execute([
        $data['hospital_id'],
        $data['appointment_date'],
        $data['appointment_time']
    ]);
    
    if ($stmt->fetchColumn() > 0) {
        throw new Exception('This time slot is already booked');
    }
    
    // Insert appointment
    $stmt = $pdo->prepare("
        INSERT INTO appointments (
            donor_id, 
            hospital_id, 
            appointment_date, 
            appointment_time, 
            status, 
            notes,
            created_at
        ) VALUES (?, ?, ?, ?, 'scheduled', ?, NOW())
    ");
    
    $stmt->execute([
        $donor['donor_id'],
        $data['hospital_id'],
        $data['appointment_date'],
        $data['appointment_time'],
        $data['notes'] ?? null
    ]);
    
    $appointmentId = $pdo->lastInsertId();
    
    // Create notification for the donor
    $stmt = $pdo->prepare("
        INSERT INTO notifications (
            user_id,
            title,
            message,
            type,
            is_read,
            created_at
        ) VALUES (?, ?, ?, 'appointment', 0, NOW())
    ");
    
    $stmt->execute([
        $_SESSION['user_id'],
        'Appointment Scheduled',
        'Your blood donation appointment has been scheduled successfully.'
    ]);
    
    // Commit transaction
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'message' => 'Appointment scheduled successfully',
        'appointment_id' => $appointmentId
    ]);

} catch (Exception $e) {
    // Rollback transaction on error
    if (isset($pdo)) {
        $pdo->rollBack();
    }
    
    error_log("Appointment scheduling error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
?> 