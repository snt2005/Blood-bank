<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Check if user is logged in and is a recipient
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'recipient') {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized access']);
    exit;
}

// Get JSON data
$data = json_decode(file_get_contents('php://input'), true);

if (!$data) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON data']);
    exit;
}

// Validate required fields
if (empty($data['blood_group']) || empty($data['units']) || empty($data['required_by']) || 
    empty($data['reason']) || empty($data['hospital_id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'All fields are required']);
    exit;
}

// Validate blood group
$valid_blood_groups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
if (!in_array($data['blood_group'], $valid_blood_groups)) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid blood group']);
    exit;
}

// Validate units
if (!is_numeric($data['units']) || $data['units'] < 1 || $data['units'] > 10) {
    http_response_code(400);
    echo json_encode(['error' => 'Units must be between 1 and 10']);
    exit;
}

// Validate required by date
$required_by = new DateTime($data['required_by']);
$today = new DateTime();
if ($required_by < $today) {
    http_response_code(400);
    echo json_encode(['error' => 'Required by date must be in the future']);
    exit;
}

try {
    $pdo = getConnection();
    $pdo->beginTransaction();
    
    // Get recipient ID
    $stmt = $pdo->prepare("SELECT recipient_id FROM recipients WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $recipient = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$recipient) {
        $pdo->rollBack();
        http_response_code(404);
        echo json_encode(['error' => 'Recipient not found']);
        exit;
    }
    
    // Validate hospital exists and is active
    $stmt = $pdo->prepare("
        SELECT h.hospital_id 
        FROM hospitals h
        JOIN users u ON h.user_id = u.user_id
        WHERE h.hospital_id = ? AND u.status = 'active'
    ");
    $stmt->execute([$data['hospital_id']]);
    if (!$stmt->fetch()) {
        $pdo->rollBack();
        http_response_code(400);
        echo json_encode(['error' => 'Invalid or inactive hospital']);
        exit;
    }
    
    // Check if recipient has any pending requests
    $stmt = $pdo->prepare("
        SELECT COUNT(*) 
        FROM blood_requests 
        WHERE recipient_id = ? AND status = 'pending'
    ");
    $stmt->execute([$recipient['recipient_id']]);
    if ($stmt->fetchColumn() > 0) {
        $pdo->rollBack();
        http_response_code(400);
        echo json_encode(['error' => 'You already have a pending blood request']);
        exit;
    }
    
    // Insert blood request
    $stmt = $pdo->prepare("
        INSERT INTO blood_requests (
            recipient_id, hospital_id, blood_group, units, 
            required_by, reason, status, request_date
        ) VALUES (?, ?, ?, ?, ?, ?, 'pending', CURRENT_TIMESTAMP)
    ");
    
    $stmt->execute([
        $recipient['recipient_id'],
        $data['hospital_id'],
        $data['blood_group'],
        $data['units'],
        $data['required_by'],
        $data['reason']
    ]);
    
    $request_id = $pdo->lastInsertId();
    
    // Create notification for the recipient
    $stmt = $pdo->prepare("
        INSERT INTO notifications (user_id, title, message, type)
        VALUES (?, 'Blood Request Submitted', 'Your blood request has been submitted successfully.', 'success')
    ");
    $stmt->execute([$_SESSION['user_id']]);
    
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'message' => 'Blood request submitted successfully',
        'request_id' => $request_id
    ]);

} catch (PDOException $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log("Submit request error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Database error occurred']);
} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log("Submit request error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'An unexpected error occurred']);
}
?> 