<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

// Check if user is logged in and is a recipient
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'recipient') {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized access']);
    exit;
}

try {
    $pdo = getConnection();
    
    // Get recipient information
    $stmt = $pdo->prepare("
        SELECT 
            r.recipient_id,
            r.name,
            r.blood_group,
            r.age,
            r.gender,
            r.contact,
            r.address,
            u.email,
            (
                SELECT MAX(request_date)
                FROM blood_requests
                WHERE recipient_id = r.recipient_id
            ) as last_request
        FROM recipients r
        JOIN users u ON r.user_id = u.user_id
        WHERE r.user_id = ?
    ");
    
    $stmt->execute([$_SESSION['user_id']]);
    $recipient = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$recipient) {
        http_response_code(404);
        echo json_encode(['error' => 'Recipient not found']);
        exit;
    }
    
    // Remove sensitive information
    unset($recipient['user_id']);
    
    echo json_encode([
        'success' => true,
        'recipient' => $recipient
    ]);

} catch (PDOException $e) {
    error_log("Recipient profile error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Database error occurred']);
} catch (Exception $e) {
    error_log("Recipient profile error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'An unexpected error occurred']);
}
?> 