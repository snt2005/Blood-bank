<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

// Check if user is logged in and is a recipient
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'recipient') {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized access']);
    exit;
}

// Get JSON data
$data = json_decode(file_get_contents('php://input'), true);

// Validate request ID
if (!isset($data['request_id']) || empty($data['request_id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Request ID is required']);
    exit;
}

try {
    $pdo = getConnection();
    
    // Start transaction
    $pdo->beginTransaction();
    
    // Get recipient ID
    $stmt = $pdo->prepare("SELECT recipient_id FROM recipients WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $recipient = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$recipient) {
        throw new Exception('Recipient not found');
    }
    
    // Check if request exists and belongs to the recipient
    $stmt = $pdo->prepare("
        SELECT request_id, status, hospital_id
        FROM blood_requests
        WHERE request_id = ? AND recipient_id = ? AND status = 'pending'
    ");
    $stmt->execute([$data['request_id'], $recipient['recipient_id']]);
    $request = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$request) {
        throw new Exception('Invalid request or request cannot be cancelled');
    }
    
    // Update request status
    $stmt = $pdo->prepare("
        UPDATE blood_requests 
        SET status = 'cancelled'
        WHERE request_id = ?
    ");
    $stmt->execute([$data['request_id']]);
    
    // Create notification for recipient
    $stmt = $pdo->prepare("
        INSERT INTO notifications (
            user_id,
            title,
            message,
            type,
            is_read,
            created_at
        ) VALUES (?, 'Blood Request Cancelled', 'Your blood request has been cancelled.', 'request', 0, CURRENT_TIMESTAMP)
    ");
    $stmt->execute([$_SESSION['user_id']]);
    
    // Create notification for hospital
    $stmt = $pdo->prepare("
        INSERT INTO notifications (
            user_id,
            title,
            message,
            type,
            is_read,
            created_at
        ) VALUES (
            (SELECT user_id FROM hospitals WHERE hospital_id = ?),
            'Blood Request Cancelled',
            'A blood request has been cancelled.',
            'request',
            0,
            CURRENT_TIMESTAMP
        )
    ");
    $stmt->execute([$request['hospital_id']]);
    
    // Commit transaction
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'message' => 'Blood request cancelled successfully'
    ]);

} catch (Exception $e) {
    // Rollback transaction on error
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    error_log("Cancel blood request error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
?> 