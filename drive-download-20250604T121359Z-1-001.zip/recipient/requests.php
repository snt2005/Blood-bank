<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is a recipient
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'recipient') {
    header('Location: ../login.html');
    exit;
}

try {
    $pdo = getConnection();
    
    // Get recipient information
    $stmt = $pdo->prepare("
        SELECT r.*, u.email, u.username
        FROM recipients r
        JOIN users u ON r.user_id = u.user_id
        WHERE r.user_id = ?
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $recipient = $stmt->fetch(PDO::FETCH_ASSOC);

    // Get all hospitals
    $stmt = $pdo->prepare("
        SELECT hospital_id, name, city
        FROM hospitals
        WHERE status = 'active'
        ORDER BY name
    ");
    $stmt->execute();
    $hospitals = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Get all blood requests
    $stmt = $pdo->prepare("
        SELECT 
            br.*,
            h.name as hospital_name
        FROM blood_requests br
        JOIN hospitals h ON br.hospital_id = h.hospital_id
        WHERE br.recipient_id = ?
        ORDER BY 
            CASE br.priority
                WHEN 'emergency' THEN 1
                WHEN 'urgent' THEN 2
                ELSE 3
            END,
            br.required_date ASC
    ");
    $stmt->execute([$recipient['recipient_id']]);
    $requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    error_log("Blood requests error: " . $e->getMessage());
    $error = "An error occurred while loading the blood requests.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blood Requests - Blood Bank Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="#">Blood Bank Management System</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../recipient_dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="requests.php">Blood Requests</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="history.php">Request History</a>
                    </li>
                </ul>
                <div class="d-flex">
                    <a href="../auth/logout.php" class="btn btn-light">Logout</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <!-- New Blood Request Form -->
        <div class="card mb-4">
            <div class="card-body">
                <h5 class="card-title">New Blood Request</h5>
                <form id="requestForm" onsubmit="submitRequest(event)">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="blood_group" class="form-label">Blood Group</label>
                            <select class="form-select" id="blood_group" name="blood_group" required>
                                <option value="">Select Blood Group</option>
                                <option value="A+">A+</option>
                                <option value="A-">A-</option>
                                <option value="B+">B+</option>
                                <option value="B-">B-</option>
                                <option value="AB+">AB+</option>
                                <option value="AB-">AB-</option>
                                <option value="O+">O+</option>
                                <option value="O-">O-</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="component_type" class="form-label">Component Type</label>
                            <select class="form-select" id="component_type" name="component_type" required>
                                <option value="">Select Component</option>
                                <option value="whole_blood">Whole Blood</option>
                                <option value="red_cells">Red Blood Cells</option>
                                <option value="plasma">Plasma</option>
                                <option value="platelets">Platelets</option>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="units_required" class="form-label">Units Required</label>
                            <input type="number" class="form-control" id="units_required" name="units_required" min="1" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="required_date" class="form-label">Required Date</label>
                            <input type="text" class="form-control" id="required_date" name="required_date" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="hospital_id" class="form-label">Hospital</label>
                            <select class="form-select" id="hospital_id" name="hospital_id" required>
                                <option value="">Select Hospital</option>
                                <?php foreach ($hospitals as $hospital): ?>
                                    <option value="<?php echo $hospital['hospital_id']; ?>">
                                        <?php echo htmlspecialchars($hospital['name'] . ' - ' . $hospital['city']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="priority" class="form-label">Priority</label>
                            <select class="form-select" id="priority" name="priority" required>
                                <option value="normal">Normal</option>
                                <option value="urgent">Urgent</option>
                                <option value="emergency">Emergency</option>
                            </select>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="reason" class="form-label">Reason for Request</label>
                        <textarea class="form-control" id="reason" name="reason" rows="3" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit Request</button>
                </form>
            </div>
        </div>

        <!-- Blood Requests List -->
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Your Blood Requests</h5>
                <?php if (empty($requests)): ?>
                    <p>No blood requests found.</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Blood Group</th>
                                    <th>Type</th>
                                    <th>Units</th>
                                    <th>Required Date</th>
                                    <th>Hospital</th>
                                    <th>Priority</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($requests as $request): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($request['blood_group']); ?></td>
                                        <td><?php echo htmlspecialchars($request['component_type']); ?></td>
                                        <td><?php echo htmlspecialchars($request['units_required']); ?></td>
                                        <td><?php echo date('M d, Y', strtotime($request['required_date'])); ?></td>
                                        <td><?php echo htmlspecialchars($request['hospital_name']); ?></td>
                                        <td>
                                            <span class="badge bg-<?php 
                                                echo $request['priority'] === 'emergency' ? 'danger' : 
                                                    ($request['priority'] === 'urgent' ? 'warning' : 'info'); 
                                            ?>">
                                                <?php echo ucfirst($request['priority']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="badge bg-<?php 
                                                echo $request['status'] === 'approved' ? 'success' : 
                                                    ($request['status'] === 'rejected' ? 'danger' : 'warning'); 
                                            ?>">
                                                <?php echo ucfirst($request['status']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <?php if ($request['status'] === 'pending'): ?>
                                                <button onclick="cancelRequest(<?php echo $request['request_id']; ?>)" 
                                                        class="btn btn-sm btn-danger">
                                                    Cancel
                                                </button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script>
        // Initialize date picker
        flatpickr("#required_date", {
            minDate: "today",
            dateFormat: "Y-m-d",
            disableMobile: "true"
        });

        function submitRequest(event) {
            event.preventDefault();
            
            const form = event.target;
            const formData = new FormData(form);
            const data = Object.fromEntries(formData.entries());

            fetch('create_request.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Blood request submitted successfully!');
                    window.location.reload();
                } else {
                    alert(data.error || 'Failed to submit blood request');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while submitting the request');
            });
        }

        function cancelRequest(requestId) {
            if (confirm('Are you sure you want to cancel this blood request?')) {
                fetch('cancel_request.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        request_id: requestId
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Blood request cancelled successfully!');
                        window.location.reload();
                    } else {
                        alert(data.error || 'Failed to cancel blood request');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred while cancelling the request');
                });
            }
        }
    </script>
</body>
</html> 